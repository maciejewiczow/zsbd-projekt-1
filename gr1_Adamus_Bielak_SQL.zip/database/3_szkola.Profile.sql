INSERT INTO szkola.Profile (ShortName) VALUES ('a'),
 ('b'),
 ('c'),
 ('d');

