export default function LoadingClasses() {
    return <>Loading...</>;
}
