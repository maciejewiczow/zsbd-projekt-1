'use client';

import { Layout } from 'antd';

const { Header, Sider, Content, Footer } = Layout;
export { Header, Sider, Content, Footer, Layout };
