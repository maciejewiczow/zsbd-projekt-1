/** @type {import('next').NextConfig} */
const nextConfig = {
    transpilePackages: ['antd'],
};

export default nextConfig;
